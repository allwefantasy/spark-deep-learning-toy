class Job(object):
    def echo(self, m):
        return m + ":job"

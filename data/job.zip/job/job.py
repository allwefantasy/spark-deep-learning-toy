class Job(object):
    pass
